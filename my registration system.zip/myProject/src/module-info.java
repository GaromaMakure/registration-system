module MyRegistrationSystem {
}