package myProject;

// class for the course information

class Course {
    String courseName;
    String courseCode;
    int creditHours;

    public Course(String name, String code, int hours) {
        this.courseName = name;
        this.courseCode = code;
        this.creditHours = hours;
    }

}