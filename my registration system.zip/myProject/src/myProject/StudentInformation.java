package myProject;

	// Interface for common student information
interface StudentInformation {
	    void studInfoInput();

	}

